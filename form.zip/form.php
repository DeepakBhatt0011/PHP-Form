<?php
$insert = false;
if (isset($_POST['name'])) {

    // Set Connection Variables
    $server = "localhost";
    $username = "root";
    $password = "";

    // Create a Database Connection
    $con = mysqli_connect($server, $username, $password, $);

    // Execute the Query
    if (!$con) {
        die("Connection to this Database failed due to" . mysqli_connect_error());
    }
    echo "Success Connection to the Database";

    // Collect Post Variables   
    $name = $_POST['name'];
    $father_name = $_POST['fname'];
    $mother_name = $_POST['mname'];
    $contact_number = $_POST['phone'];


    $sql = "INSERT INTO 'student_details'.'student' (`Name`, `Father Name`, `Mother Name`, `Contact Number`) VALUES ('$name', '$fname', '$mname', '$phone')";


    echo $sql;

    if ($con->query($sql) == true) {
        // echo "Successfuly Inserted";

        // Flag for Successful Insertion
        $insert = true;
    } else {
        echo "ERROR: $sql <br> $con-> error";
    }

    // Close the Database Connection
    $con->close();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=\, initial-scale=1.0" />
    <!-- StyleSheets -->
    <link rel="stylesheet" href="form.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet" />
    <!-- Title -->
    <title>Student_Details</title>
</head>

<body>
    <div class="login-box">
        <h1>Student Details</h1>
        <?php
        if ($insert == true) {
            echo "<p class='sumbmitmsg'>Thanks for Sumbmitting this form</p>";
        }
        ?>
        <form action="form.php" method="post">
            <div class="user-box">
                <input type="text" name="name" id="name" required="" />
                <label>Name</label>
            </div>
            <div class="user-box">
                <input type="text" name="fname" id="fname" required="" />
                <label>Father's Name</label>
            </div>
            <div class="user-box">
                <input type="text" name="mname" id="mname" required="" />
                <label>Mother's Name</label>
            </div>
            <div class="user-box">
                <input type="tel" name="phone" id="phone" required="" />
                <label>Contact Number</label>
            </div>
            <center>
                <a href="#">
                    SEND
                    <span></span>
                </a>
            </center>
        </form>
    </div>
</body>

</html>